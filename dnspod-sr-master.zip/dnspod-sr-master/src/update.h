#ifndef __RECV_UPDATE_H__
#define __RECV_UPDATE_H__
#include "control.h"

#define CACHE_FLUSH 1
#define HIJACK  2
int start_local_server();

#endif
